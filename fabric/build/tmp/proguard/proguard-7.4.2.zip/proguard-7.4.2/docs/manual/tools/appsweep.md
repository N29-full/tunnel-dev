# AppSweep

[AppSweep](https://appsweep.guardsquare.com/) is a free online app security testing tool that allows you to find and fix security
issues in your Android app's code and dependencies.

<center>
![](appsweep.png)
</center>
